<?php $__env->startSection('title' ,'Notifications'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="cm-md-4">
            <navigation></navigation>
        </div>
        <div class="col-md-8 " >
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
                            &times;
                        </button>
                        <?php echo e(Session::get('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="panel panel-default custom-panel" style="background-color:#f8f8f8;">
                    <div class="panel-body box-style box-style-no-padding"  style="background-color:#fff;">

                        <div class="col-md-12 custom-design panel-heading">
                            <?php if( Auth::user()->unreadNotifications->count()  != 0): ?>
                                <div class="col-md-6">You have <?php echo e(Auth::user()->unreadNotifications->count()); ?> unread <?php if( Auth::user()->unreadNotifications->count() == 1): ?>  notification <?php else: ?> notifications <?php endif; ?>
                                </div>
                                <div class="col-md-6 text-right"><a href="<?php echo e(Auth::user()->isCLient() ? url('/client/mark-all-notifications-as-read')  : url('/admin/mark-all-notifications-as-read')); ?>" > Mark all as read </a></div>

                            <?php else: ?>
                                You have no new notifications

                            <?php endif; ?>
                        </div>
                        <div class="box">
                            <div class="box-body">
                                <table  class="table table-bordered ">
                                    <tbody>
                                    <?php $__currentLoopData = Auth::user()->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="background-color: <?php echo e($notification->read_at == '' ? '#f8f8f8': ''); ?>;">
                                                <?php echo $__env->make( 'notifications.'. snake_case( class_basename( $notification->type ) ) , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>