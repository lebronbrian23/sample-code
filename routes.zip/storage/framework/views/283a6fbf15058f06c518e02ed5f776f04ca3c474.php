<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Register</div>
                <?php if(Session::has('error')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
                            &times;
                        </button>
                        <?php echo e(Session::get('error')); ?>

                    </div>
                <?php endif; ?>
                <div class="panel-body">
                    <form class="form-horizontal" method="POST"  action="<?php echo e(route('register')); ?>" >
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Name</label>

                            <div class="col-md-6 <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <input id="name" type="text" class="form-control" name="name"  required autofocus>
                            </div>
                            <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group <?php echo e($errors->has('mobile_no') ? ' has-error' : ''); ?>">
                            <label for="phone" class="col-md-4 control-label">Mobile Phone</label>

                            <div class="col-md-6">
                                <input id="mobile_no" type="number" class="form-control" name="mobile_no"  required>
                            </div>
                            <?php if($errors->has('mobile_no')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('mobile_no')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary" >
                                    Register
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>