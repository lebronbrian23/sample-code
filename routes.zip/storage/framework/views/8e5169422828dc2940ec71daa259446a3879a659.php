<li style="background-color: <?php echo e($notification->read_at == '' ? '#f8f8f8': ''); ?>;">
    <a href="<?php echo e(Auth::user()->isCLient() ? url('client/notification-read/'.$notification->id.'/'.$notification->data['user_id'].'/'.$notification->data['item_name'] ) : url('admin/notification-read/'.$notification->id.'/'.$notification->data['user_id'].'/'.$notification->data['item_name'] )); ?>">
        <i class="fa fa-gift text-aqua"></i>  <?php echo e($notification->data['seller_name']); ?>, <?php echo e($notification->data['seller_phone']); ?> , has <?php echo e($notification->data['item_name']); ?> , <?php echo e($notification->data['location']); ?>

        <small style="float:right"><i class="fa fa-clock-o"></i> <?php echo e($notification->created_at->diffForHumans()); ?></small>
    </a>
</li>
