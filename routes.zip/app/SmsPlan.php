<?php

namespace WantedSasa;

use Illuminate\Database\Eloquent\Model;

class SmsPlan extends Model
{
    //
}
