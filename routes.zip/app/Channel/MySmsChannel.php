<?php
/**
 * Created by PhpStorm.
 * User: Lebron Brian Cowen
 * Date: 5/5/2018
 * Time: 3:58 PM
 */

namespace WantedSasa\Channel;

use AfricasTalking\SDK\AfricasTalking;
use Illuminate\Notifications\Notification;


class MySmsChannel
{
    /**
     * Send the given notification.
     *
     * @param  mixed  $notifiable
     * @param  \Illuminate\Notifications\Notification  $notification
     * @return void
     */
    public function send($notifiable, Notification $notification)
    {
        $username = 'sandbox'; // use 'sandbox' for development in the test environment
        $apiKey 	= '1c93f3351e1ad7e334917539590a33cd8939ed038f78c6c352864db04f8d1853'; // use your sandbox app API key for development in the test environment
        $username = 'lebronbrian23@gmail.com'; // use 'sandbox' for development in the test environment
        $apiKey 	= 'e06caf6c39b8d55e8a8646760f3977c86de68b337a3de147d2a81d4154a29c50'; // use your sandbox app API key for development in the test environment

        if (! $to = $notifiable->routeNotificationFor('AfricasTalking')) {
            return;
        }
        $AT = new AfricasTalking($username, $apiKey);
        $message = $notification->toSms($notifiable);
        $options = [
            'message' => $message ,
            'to' => $to,
            //'from' => ,
            'enqueue' => true
        ];
        $SMS = $AT->sms();
        $SMS->send($options);
        // Send notification to the $notifiable instance...
    }
}